def say_hello(name):
    print(f'Konnichiwa! I\'m {name}')
          

def say_bye():
    print('Hasta la vista, baby')
