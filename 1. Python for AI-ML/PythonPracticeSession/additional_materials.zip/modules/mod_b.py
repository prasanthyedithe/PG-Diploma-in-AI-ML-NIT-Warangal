import mod_c


mod_c.x = 1000
