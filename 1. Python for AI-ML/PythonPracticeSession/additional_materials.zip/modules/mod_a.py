
from mod_b import *
from mod_c import *

print(x)



