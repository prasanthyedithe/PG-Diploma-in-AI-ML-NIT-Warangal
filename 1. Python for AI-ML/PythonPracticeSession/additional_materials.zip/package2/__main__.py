import sys

from skill_java import java


print('#--------------')
print(sys.path)
print('#--------------')


if __name__ == '__main__':
    java()
