def java():
    print('Skill Java')
