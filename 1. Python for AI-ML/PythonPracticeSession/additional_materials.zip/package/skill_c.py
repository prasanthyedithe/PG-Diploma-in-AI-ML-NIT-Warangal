def c():
    print('Skill c')
