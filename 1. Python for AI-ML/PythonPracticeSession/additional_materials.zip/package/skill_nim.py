def nim():
    print('Skill nim')
