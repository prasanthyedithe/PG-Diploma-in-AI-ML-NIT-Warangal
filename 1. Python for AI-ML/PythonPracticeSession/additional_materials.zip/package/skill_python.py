def python():
    print('Skill python')
