def linux():
    print('Skill linux')
