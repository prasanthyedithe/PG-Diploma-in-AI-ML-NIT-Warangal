import streamlit as st 
import pandas as pd 
import datetime as dt
import pickle
import boto3
import sagemaker

brands=['Ambassador',
 'Ashok',
 'Audi',
 'BMW',
 'Chevrolet',
 'Daewoo',
 'Datsun',
 'Fiat',
 'Force',
 'Ford',
 'Honda',
 'Hyundai',
 'Isuzu',
 'Jaguar',
 'Jeep',
 'Kia',
 'Land',
 'Lexus',
 'MG',
 'Mahindra',
 'Maruti',
 'Mercedes-Benz',
 'Mitsubishi',
 'Nissan',
 'Opel',
 'Peugeot',
 'Renault',
 'Skoda',
 'Tata',
 'Toyota',
 'Volkswagen',
 'Volvo']

stype=['Individual','Dealer','Trustmark Dealer']
otype=['First Owner', 'Second Owner', 'Third Owner', 'Fourth & Above Owner',
       'Test Drive Car']
ttype=['Manual', 'Automatic']
def type_year(item):
    if item<2000:
        return 'Vintage'
    elif item<2015:
        return 'Old'
    else:
        return 'New'
def rescale(val,col,scaler):
    norm_data=['km_driven','mileage','max_power','engine']
    ind=norm_data.index(col)
    return (val-scaler.mean_[ind])/scaler.scale_[ind]



def get_price(payload):
   keys=pd.read_csv('accessKeys.csv') # This should be downloaded by the learner
   sessionboto = boto3.Session(aws_access_key_id=keys['Access key ID'][0],
                           aws_secret_access_key=keys['Secret access key'][0],
                           region_name='us-west-1')
   session = sagemaker.Session(boto_session=sessionboto)
   runtime=session.sagemaker_runtime_client
   endpoint_name = 'Your-Endpoint-Name'                             # Your endpoint name.
   content_type = "text/csv"                                        # The MIME type of the input data in the request body.
   accept = 'text/csv'                                              # The desired MIME type of the inference in the response.
   payload =  payload
   response = runtime.invoke_endpoint(
      EndpointName=endpoint_name, 
      ContentType=content_type,
      Accept=accept,
      Body=payload
      )

   print(response)
   return response['Body'].read()     

##### Background setup
page_bg_img = '''
<style>
.body{
background-color: linear-gradient(to bottom, rgba(2,0,36,1), rgba(0,212,255,1));
}
</style>
'''

st.markdown(page_bg_img, unsafe_allow_html=True)



## take the observations
st.markdown('# Car Price Predictor')
make=st.selectbox('Brand of the Car: ',brands)
ear=st.date_input('Year Make of the Car: ',min_value=dt.date(1980,1,1), max_value=dt.date.today())
year=type_year(ear.year)
km_driven=st.number_input('KM driven: ',min_value=1000.0 , max_value=10000000.0,step=1000.0)
fuel=st.selectbox('Fuel Type: ',['Diesel','Petrol','CNG','LPG'])
seller_type=st.selectbox('Type of Seller: ',stype)
transmission=st.selectbox('Type of Transmission: ',ttype)
owner=st.selectbox('Type of Owner: ',otype)
mileage=st.number_input('Mileage(kmpl): ',min_value=1.0 , max_value=500.0,step=.01)
engine=st.number_input('Engine(CC): ',min_value=1.0 , max_value=3500.0,step=.01)
max_power=st.number_input('Max Power(bhp): ',min_value=1.0 , max_value=500.0,step=.01)
seats=st.select_slider('Number of seats: ',sorted([5.0, 7.0, 8.0, 4.0, 9.0, 6.0, 10.0, 2.0, 14.0]))
import time
st.empty()
button=st.button('Calculate')
if button:
   with st.spinner('calculating the price....'):
      dummies=pickle.load(open('scaler.pickle','rb'))
      columns=pickle.load(open('test_columns.pickle','rb'))
      scaler=pickle.load(open('scaler.pickle','rb'))
      
      columns={col:0 for col in columns}
      columns['km_driven']=rescale(km_driven,'km_driven',scaler)
      columns['mileage']=rescale(mileage,'mileage',scaler)
      columns['engine']=rescale(engine,'engine',scaler)
      columns['max_power']=rescale(max_power,'max_power',scaler)
      columns['fuel_'+fuel]=1
      columns['seller_type_'+seller_type]=1
      columns['transmission_'+transmission]=1
      columns['owner_'+owner]=1
      columns['seats_'+str(seats)]=1
      columns['name_'+make]=1
      columns['age_class_'+year]=1
      out=str(list(columns.values())[0])
      for i in list(columns.values())[1:]:
         out=out+','+str(i)
      price = get_price(out)
   st.success('Congrats! You can sell your car at: (Rs.)'+str(round(float(price),2)))
   st.balloons()